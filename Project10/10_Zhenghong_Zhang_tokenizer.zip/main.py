import sys
import pathlib
from tokenizer import Tokenizer


class Constructor(object):
    def __init__(self, path):
        self.path = pathlib.Path(path)

    def run(self):
        try:
            if self.path.is_file():
                with open(self.path, mode='r') as source:
                    # Out path for tokenizer only
                    out = open(self.path.parent.joinpath(
                        f"{self.path.name.replace(self.path.suffix, '')}T.xml"), mode='w')
                    t = Tokenizer(source)
                    out.write('<tokens>\n')
                    for item in t.tag_adder():
                        out.write(f'{item}\n')
                    # t.tag_adder()
                    out.write('</tokens>\n')
                    out.close()
            elif self.path.is_dir():
                for singlefile in self.path.glob('*.jack'):
                    with open(singlefile, mode='r') as source:
                        # Out path for tokenizer only
                        out = open(singlefile.parent.joinpath(
                            f"{singlefile.name.replace(singlefile.suffix, '')}T.xml"), mode='w')
                        t = Tokenizer(source)
                        out.write('<tokens>\n')
                        for item in t.tag_adder():
                            out.write(f'{item}\n')
                        out.write('</tokens>\n')
                        print(f'Finished {source.name}')
                        out.close()
                        # t.tag_adder()
            else:
                raise FileNotFoundError
        except FileNotFoundError:
            print(f'Did not find {self.path}, Please try again.')


input_path = sys.argv[1]
test = Constructor(input_path)
test.run()
